
Step 1: Unity Scene Setup:

Create a new VRC Avatar Project through the VRChat Creator Companion.
Official VRChat documentation for creating a project can be found here:

https://creators.vrchat.com/avatars/creating-your-first-avatar/

---------------------------

Step2 : Import Poyomi 9.0.57:

Download the unitypackage here:
https://github.com/poiyomi/PoiyomiToonShader/releases/tag/v9.0.57

Specifically, click the link for poi_Toon_7.3.50_UpTo_9.0.57.unitypackage to download the files you need.

Install the poyomi unitypackage into the project using Assets>Import Package>Custom Package, and select the poyomi unitypackage from wherever you have it saved on the computer.

---------------------------

Step 3: Import Ghost Hands into Unity

Install the project assets into the project using Assets>Import Package>Custom Package, and select GhostHands.unitypackage. This will import all the assets into your unity project folder.

---------------------------

Step 4: Open the Scene

in the unity project window, open Model> Ghosthands_MainScene.

You should now see the ghost hands in the 3d view.

---------------------------

Step 5: Upload the project to your account

Open VRChatSDK > Show Control Panel.

Enter your vrchat login credentials.
Check the Builder tab- if there are no warnings or errors, go ahead and hit the "Build and Publish" button at the bottom to upload the avatar.